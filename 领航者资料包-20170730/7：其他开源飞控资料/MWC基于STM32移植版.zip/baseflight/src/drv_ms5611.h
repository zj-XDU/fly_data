#pragma once

bool ms5611Detect(baro_t *baro);
