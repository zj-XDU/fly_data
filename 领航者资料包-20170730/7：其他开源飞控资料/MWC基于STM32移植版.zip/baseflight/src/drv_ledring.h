#pragma once

bool ledringDetect(void);
void ledringState(void);
void ledringBlink(void);
