#pragma once

bool bmp085Detect(baro_t *baro);
