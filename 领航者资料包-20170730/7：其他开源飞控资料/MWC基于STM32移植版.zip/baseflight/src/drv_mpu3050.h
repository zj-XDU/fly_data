#pragma once

bool mpu3050Detect(sensor_t *gyro);
void mpu3050Config(uint16_t lpf);
